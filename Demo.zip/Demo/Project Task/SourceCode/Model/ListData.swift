//
//  ListData.swift
//  Project Task
//
//  Created by ESEARCH05 on 14/03/23.
//

import Foundation

struct ListData: Codable {
    var id: Int
    var title: String
    var price: Double
    var description: String
    var category: String
    var image: String
    var rating: Rate
}

struct Rate: Codable {
    var rate: Double
    var count: Int
}
