//
//  DetailsTableViewCell.swift
//  Project Task
//
//  Created by ESEARCH05 on 15/03/23.
//

import UIKit

class DetailsTableViewCell: UITableViewCell {
    @IBOutlet weak var buttonUpdate: UIButton!
    
    @IBOutlet weak var buttonDelete: UIButton!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var labelCount: UILabel!
    @IBOutlet weak var labelRate: UILabel!
    @IBOutlet weak var labelPrice: UILabel!
    @IBOutlet weak var labelCat: UILabel!
    @IBOutlet weak var labelDescription: UILabel!
    var product : ListData?{
        didSet{
            productDetailConfiguration()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func productDetailConfiguration() {
        guard let title = product?.title ,
              let cat = product?.category,
                let desc = product?.description,
                let count = product?.rating.count,
              let rate = product?.rating.rate,
              let price = product?.price else {
            return
        }
              
        labelTitle.text = title
        labelCat.text = "Catagory: " + cat
        labelDescription.text = desc
        labelCount.text = "Product Count: " + "\(String(describing: count))"
        labelPrice.text = "Price: $\(price)"
        labelRate.text =  "Rate: " + "\(rate)"
        img.downlodeImage(serviceurl: product?.image ?? "", placeHolder: UIImage(named: ""))
    }
    
}
