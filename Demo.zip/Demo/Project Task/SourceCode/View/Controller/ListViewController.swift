//
//  ListViewController.swift
//  Project Task
//
//  Created by ESEARCH05 on 14/03/23.
//

import UIKit

class ListViewController: UIViewController {
    @IBOutlet weak var tableview: UITableView!
    
    
    lazy var viewModel = {
        ListViewModel()
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        initViewModel()
        self.tableview.delegate = self
        self.tableview.dataSource = self
        configuration()
    }
    
    @IBAction func buttonTappedAdd(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddListDataViewController") as! AddListDataViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}


extension ListViewController {

    func configuration() {
        tableview.register(UINib(nibName: "ProductTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductTableViewCell")
        
       
    }

    func initViewModel() {
        viewModel.listProduct()
        viewModel.reloadTableView = { [weak self] in
           
            DispatchQueue.main.async {
                self?.tableview.reloadData()
            }
            
        }
    }

   

}

extension ListViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.list.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell") as? ProductTableViewCell else {
            return UITableViewCell()
        }
        let product = viewModel.list[indexPath.row]
        cell.product = product
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsVC") as! ProductDetailsVC
        vc.id = "\(viewModel.list[indexPath.row].id)"
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
