//
//  ProductDetailsVC.swift
//  Project Task
//
//  Created by ESEARCH05 on 15/03/23.
//

import UIKit

class ProductDetailsVC: UIViewController {

    @IBOutlet weak var tableview: UITableView!
    
    lazy var viewModel = {
        DetailsViewModel()
    }()
    var id = ""
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.tableview.delegate = self
        self.tableview.dataSource = self
        configuration()
        self.initViewModel(id: id)
    }
    
    func configuration(){
        tableview.register(UINib(nibName: "DetailsTableViewCell", bundle: nil), forCellReuseIdentifier: "DetailsTableViewCell")
    }

    
    func initViewModel(id:String) {
        viewModel.listProduct(id: id)
        viewModel.reloadTableView = { [weak self] in
           
            DispatchQueue.main.async {
                self?.tableview.reloadData()
            }
            
        }
    }


}

extension ProductDetailsVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailsTableViewCell") as! DetailsTableViewCell
        cell.product = viewModel.details
        cell.buttonDelete.addTarget(self, action: #selector(buttonTappedDelete), for: .touchUpInside)
        cell.buttonDelete.tag = indexPath.row
        cell.buttonUpdate.addTarget(self, action: #selector(buttonTappedUpdate), for: .touchUpInside)
        cell.buttonUpdate.tag = indexPath.row
        return cell
    }
    
    @objc func buttonTappedDelete(sender: UIButton){
        guard let id = viewModel.details?.id else{
            return
        }
        viewModel.deleteProduct(id: "\(id)")
        viewModel.CallBack = { [weak self] in
            print("Deleted Successfully!....")
        }
    }
    
    
    @objc func buttonTappedUpdate(sender: UIButton){
        guard let id = viewModel.details?.id else{
            return
        }
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddListDataViewController") as! AddListDataViewController
        vc.product = viewModel.details
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
