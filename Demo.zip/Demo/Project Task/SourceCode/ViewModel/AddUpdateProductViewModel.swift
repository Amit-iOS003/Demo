//
//  AddUpdateProductViewModel.swift
//  Project Task
//
//  Created by ESEARCH05 on 15/03/23.
//

import Foundation


class AddUpdateViewModel : NSObject{
    var callBack:(()->Void)?
    
    func doAdd(title:String, price:String, desc:String, cat:String) {
        guard let url = URL(string: "https://fakestoreapi.com/products") else { return }
        let parameters = AddListData(title: title, price: price, description: desc, category: cat)
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        request.httpBody = try? JSONEncoder().encode(parameters)
        
        
        
        request.allHTTPHeaderFields = [
            "Content-Type": "application/json"
        ]
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            
            do {
                
                let response = try JSONDecoder().decode(AddListData.self, from: (data ?? data)!)
                print(response.title)
                self.callBack?()
                
            }catch {
                print(error)
            }
        }.resume()
    }
}
